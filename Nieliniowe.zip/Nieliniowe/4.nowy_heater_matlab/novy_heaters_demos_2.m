
% % Testy
% for i=0:1
% %while(1)
%     
% fprintf(s,'2000 2000 2000');
% pause(2);
% 
% fprintf(s,'-2000 -2000 -2000');
% pause(2);
% 
% end


    krokiA=0; krokiB=0; krokiC=0;
    stare_A=0; stare_B=0; stare_C=0;
    
for t = 0 : 0.1 : 10 
    
   
    a = round(8000 * sin(t));
    b = round(8000 * sin(t+2*pi/3));
    c = round(8000 * sin(t+4*pi/3));
    
    krokiA = a - stare_A;
    krokiB = b - stare_B;
    krokiC = c - stare_C;
    
    
    fprintf(s, '%d %d %d \n' , [krokiA, krokiB, krokiC ]);
    
    stare_A = a;
    stare_B = b;
    stare_C = c;
    
        
    while(s.BytesAvailable==0)       
    end
    
    while(s.BytesAvailable>0)       
        fscanf(s);
    end
    

end