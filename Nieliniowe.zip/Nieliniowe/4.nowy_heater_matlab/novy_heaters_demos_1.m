
s = serial('/dev/ttyUSB12');

s.BaudRate = 115200;

fopen(s);