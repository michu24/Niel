%% Program generuj�cy wykres temperatury czujnika na postawie danych z dokumentacji ( zmienna A )

clear all; clc

%      x     y
% [  temp  wart_x ; ... ]
A=[    1    713   ; 17 300 ; 20 290 ; 23 280 ; 27 270 ; 31 260 ; 37 250 ;
   43 240 ; 51 230 ; 61 220 ; 73 210 ; 87 200 ; 106 190;128 180 ;
  155 170 ;189 160 ;230 150 ;278 140 ;336 130 ;402 120 ;476 110 ;
  554 100 ;635  90 ;713  80 ;784  70 ;846  60 ;897  50 ;937  40 ;
  966  30 ;986  20 ;1000  10;1010   0 ];

figure(1)
plot(A(:,1),A(:,2));

hold on
x(1)=A(12,1);    y(1)=A(12,2);
x(2)=A(17,1);    y(2)=A(17,2);
x(3)=A(24,1);    y(3)=A(24,2);
x(4)=A(end-2,1); y(4)=A(end-2,2);

plot(x,y,'*');

%% Program generuj�cy wykres na postawie danych z dokumentacji ( zmienna A ) w por�wnaniu do utworzonego algorytmu 

figure(2)

plot(A(:,1),A(:,2));
hold on
L = inv(x'.^[3 2 1 0])*(y')
for x1 = 10:10:1023
    y1 = L(1)*x1^3 + L(2)*x1^2 + L(3)*x1^1 + L(4);
    plot(x1,y1,'o');
end