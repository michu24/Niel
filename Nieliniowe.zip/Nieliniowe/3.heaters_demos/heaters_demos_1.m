
s = serial('/dev/ttyUSB1');

s.BaudRate = 115200;

fopen(s);