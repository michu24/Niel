
%%
for i=0:5
%while(1)
    
fprintf(s,'1 1 1 200 200 200');
pause(2);

fprintf(s,'0 0 0 200 200 200');
pause(2);

end


%%
k1 = 1;k2 = 1;k3 = 1; 

stare = 0;
for t = 0 : 0.1 : 10 
    
    a = round (100 * sin(t));
    
    if a>0 
        
        k1 = 1; 
        k2 = 1; 
        k3 = 1;
        
    end
    
    if a<0
        
        k1 = 0; 
        k2 = 0; 
        k3 = 0;
        
    end
        
    fprintf(s, '%d %d %d %d %d %d /n', [k1, k2, k3, a-stare, a-stare, a-stare]);
    
%     while (s.BytesAvailable == 0)
%         0;
%     end
%     
%     while (s.BytesAvailable >  0)
%         fscanf(s);
%     end
     
     stare = a;
     
end